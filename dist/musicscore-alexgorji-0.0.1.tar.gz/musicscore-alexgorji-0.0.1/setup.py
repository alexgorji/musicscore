import setuptools

setuptools.setup(
    name="musicscore-alexgorji",
    version="0.0.1",
    author="Alex Gorji",
    author_email="aligorji@hotmail.com",
    description="generating musicxml",
    url="https://github.com/alexgorji/musicscore.git",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ]
)
