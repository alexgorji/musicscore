from unittest import TestCase
import os

from musicscore.musicstream.streamvoice import SimpleFormat
from musicscore.musictree.treescoretimewise import TreeScoreTimewise
from musicscore.musicxml.score_templates.xml_test_score import TestScore

path = os.path.abspath(__file__).split('.')[0]


class Test(TestCase):
    def setUp(self) -> None:
        self.score = TreeScoreTimewise()

    def test_1(self):
        sf = SimpleFormat(durations=[1, 3.5])
        v = sf.to_voice(1)
        v.add_to_score(self.score, 2, 2)
        result_path = path + '_test_1'
        self.score.write(path=result_path)

        TestScore().assert_template(result_path=result_path)
